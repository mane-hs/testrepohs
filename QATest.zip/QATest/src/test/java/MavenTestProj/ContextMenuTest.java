package MavenTestProj;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class ContextMenuTest extends basePage {

@Test
	public static void setUp1() throws IOException {
		
	driver = initializeDriver();
	driver.get(basePage.URL);
	
	//here should be called the WebElement node to right click on it
	
	NodesPage c= new NodesPage(driver);
	/* Point point = (Point) c.selectNodes();
	 int xcord = (int) point.getX();
	 int ycord = (int) point.getY();
	 Actions builder = new Actions(driver);   
	 builder.moveToElement(c, xcord, ycord).click().build().perform();*/
	 
	c.clickContextMenu1().click();
	System.out.println(driver.switchTo().alert().getText());
	driver.switchTo().alert().accept();
	
	c.clickContextMenu2().click();
	System.out.println(driver.switchTo().alert().getText());
	driver.switchTo().alert().accept();
	
	c.clickContextMenu3().click();
	System.out.println(driver.switchTo().alert().getText());
	driver.switchTo().alert().accept();
		
}

@AfterTest
public void teardown()
{
	
	driver.close();
	driver=null;
	
}

}

   

