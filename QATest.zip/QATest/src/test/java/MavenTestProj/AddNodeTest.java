package MavenTestProj;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class AddNodeTest extends basePage {
	

	@Test

	public void setUp() throws IOException {
		
		driver = initializeDriver();
		driver.get(basePage.URL);
		
		NodesPage n= new NodesPage(driver);
		n.addNodes().click();
	
	}
	
	@AfterTest
	public void teardown()
	{
		
		driver.close();
		driver=null;
		
	}
}
