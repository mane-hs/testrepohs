package MavenTestProj;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class SelectNodesTest extends basePage {
	
@Test

public static void setUp() throws IOException {
	

	driver = initializeDriver();
	driver.get(basePage.URL);
	
	//NodesPage s= new NodesPage(driver);
	
	//Point point = (Point) s.selectNodes();
	 //int xcord = (int) point.getX();
	 //int ycord = (int) point.getY();
	 //Actions builder = new Actions(driver);   
	 //builder.moveToElement(s, xcord, ycord).click().build().perform();
	 
	
	}


@AfterTest
public void teardown()
{
	
	driver.close();
	driver=null;
	
}
}
